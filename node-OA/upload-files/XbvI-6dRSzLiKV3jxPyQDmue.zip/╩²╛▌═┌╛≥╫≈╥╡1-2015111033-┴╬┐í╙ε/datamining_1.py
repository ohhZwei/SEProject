# -*- coding: utf-8 -*-
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from scipy import stats
import pylab
import xlrd
import xlwt

# df.head()
# print(df)
def supplement(df):
    # print(df)
    df['BASE_POINTS_SUM'].fillna(df['BASE_POINTS_SUM'].mean(), inplace = True)
    df['EXPENSE_SUM_YR_1'].fillna(df['EXPENSE_SUM_YR_1'].mean(), inplace = True)
    df['EXPENSE_SUM_YR_2'].fillna(df['EXPENSE_SUM_YR_2'].mean(), inplace = True)
    df['SEG_KM_SUM'].fillna(df['SEG_KM_SUM'].mean(), inplace = True)
    df['WEIGHTED_SEG_KM'].fillna(df['WEIGHTED_SEG_KM'].mean(), inplace = True)
    df['AVG_BASE_POINTS_SUM'].fillna(df['AVG_BASE_POINTS_SUM'].mean(), inplace = True)
    df['avg_discount'].fillna(df['avg_discount'].mean(), inplace = True)
    df['P1Y_BASE_POINTS_SUM'].fillna(df['P1Y_BASE_POINTS_SUM'].mean(), inplace = True)
    df['L1Y_BASE_POINTS_SUM'].fillna(df['L1Y_BASE_POINTS_SUM'].mean(), inplace = True)
    df['Points_Sum'].fillna(df['Points_Sum'].mean(), inplace = True)
    df['L1Y_Points_Sum'].fillna(df['L1Y_Points_Sum'].mean(), inplace = True)
    print("mean(['BASE_POINTS_SUM']) = ", df['BASE_POINTS_SUM'].mean())
    print("mean(['EXPENSE_SUM_YR_1']) = ", df['EXPENSE_SUM_YR_1'].mean())
    print("mean(['EXPENSE_SUM_YR_2']) = ", df['EXPENSE_SUM_YR_2'].mean())
    # print(df)
    df.to_excel("dealtdata_1.xls", sheet_name='航空公司客户数据', encoding="gbk", index = False)        # 将补充过的数据写入新的.xls文件并保存
    return df

def standarlize(df, columnname):
    df[columnname] = (df[columnname] - df[columnname].min()) / (df[columnname].max() - df[columnname].min())

def standarlizeall(df):
    standarlize(df, "BASE_POINTS_SUM")
    standarlize(df, "EXPENSE_SUM_YR_1")
    standarlize(df, "EXPENSE_SUM_YR_2")
    standarlize(df, "SEG_KM_SUM")
    standarlize(df, "WEIGHTED_SEG_KM")
    standarlize(df, "AVG_BASE_POINTS_SUM")
    standarlize(df, "avg_discount")
    standarlize(df, "P1Y_BASE_POINTS_SUM")
    standarlize(df, "L1Y_BASE_POINTS_SUM")
    standarlize(df, "Points_Sum")
    standarlize(df, "L1Y_Points_Sum")
    df.to_excel("dealtdata_2.xls", sheet_name='航空公司客户数据', encoding="gbk", index = False)    # 将规范化的数据写入新的.xls文件并保存


def calquantile(df, position, columnname):      # dataframe/分位数位置-float/df列
    return df[columnname].quantile(position)

def drawboxplot(df, columnname1, columnname2):
    """plt.boxplot(df[columnname1], showmeans = True, 
                flierprops = {'marker': 'o', 'markerfacecolor': 'red', 'color': 'black'},
                labels = {'BASE_POINTS_SUM'}
                )"""
    df.boxplot([columnname1, columnname2])
    plt.title("Boxplot")
    plt.show()

def drawhist(df, columnname):       # 绘制直方图，columnname为所需数据列名
    df[columnname].plot.hist(grid = True)
    plt.title('Histtogram')
    plt.xlabel(columnname)
    plt.grid(axis='y', alpha=0.75)
    plt.show()

def drawqp(df, columnname):         # 绘制分位数图，columnname为所需数据列名
    stats.probplot(df[columnname], plot=plt)
    plt.show()


def drawscat(df, columnname1, columnname2):         # 绘制散点图，columnname1/2为所需数据列名
    plt.scatter(df[columnname1], df[columnname2])
    plt.xlabel(columnname1)
    plt.ylabel(columnname2)
    plt.show()


if __name__ == "__main__":
    df = pd.read_excel("data.xls", sheet_name='航空公司客户数据', encoding="gbk", header = 0, skiprows = [1])
    supplement(df)
    q1 = calquantile(df, 0.25, "BASE_POINTS_SUM")
    q2 = calquantile(df, 0.5, "BASE_POINTS_SUM")
    q3 = calquantile(df, 0.75, "BASE_POINTS_SUM")
    print("观测窗口总基本积分的上、中、下四分位数分别为:", q3, q2, q1)
    r1 = calquantile(df, 0.25, "EXPENSE_SUM_YR_1")
    r2 = calquantile(df, 0.5, "EXPENSE_SUM_YR_1")
    r3 = calquantile(df, 0.75, "EXPENSE_SUM_YR_1")
    print("第一年总票价的上、中、下四分位数分别为:", r3, r2, r1)
    # drawboxplot(df, "BASE_POINTS_SUM", "EXPENSE_SUM_YR_1")
    # drawhist(df, "EXPENSE_SUM_YR_2")
    # drawqp(df, "EXPENSE_SUM_YR_2")
    # drawscat(df, "BASE_POINTS_SUM", "EXPENSE_SUM_YR_2")
    standarlizeall(df)
    print(df)
   