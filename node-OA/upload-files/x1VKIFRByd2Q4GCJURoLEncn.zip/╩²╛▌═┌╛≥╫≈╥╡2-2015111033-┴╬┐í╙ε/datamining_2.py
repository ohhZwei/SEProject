# -*- coding: utf-8 -*-
import csv
import pandas as pd
import apriori_algorithm as apriori

df = pd.read_csv('data.csv')

def dfdiscretizeBirthyear(df):      # birth_year离散化函数
    return pd.qcut(df['birth_year'], 5).astype(str) + ""

def dfdiscretizeWeight(df):         # weight离散化函数
    return pd.qcut(df['weight'], 5).astype(str) + ""

def dfdiscretizeHeight(df):         # height离散化函数
    return pd.qcut(df['height'], 5).astype(str) + ""


# 替换原来数据集
def mumerizedf(df):
    df_birth_year = dfdiscretizeBirthyear(df)
    df_weight = dfdiscretizeWeight(df)
    df_height = dfdiscretizeHeight(df)
    df.drop("birth_year", inplace=True, axis=1)
    df.drop("weight", inplace=True, axis=1)
    df.drop("height", inplace=True, axis=1)
    df = pd.concat([df, df_birth_year, df_weight, df_height], axis=1)
    # print(df['birth_year'])
    # print(df['weight'])
    # print(df['height'])
    return df


if __name__ == '__main__':
    mydat = mumerizedf(df)
    # 频繁项集与支持度
    sets, sp = apriori.apriori(mydat.values, 4, 0.5)
    rules = apriori.generateRules(sets, sp, 0.95)
    print("层级:频繁项集:支持度")
    for Lk in sets:
        for freq_set in Lk:
            print(str(len(list(Lk)[0])), ':', freq_set, ' : ', sp[freq_set])
    print("强关联规则:置信度")
    for item in rules:
        print(item[0], "-->>", item[1], " : ", item[2])