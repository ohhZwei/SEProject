# -*- coding: utf-8 -*-

def create_C1(data_set):       # 大小为1的项集集合(大小为1的频繁项集)
    C1 = set()
    for t in data_set:
        for item in t:
            item_set = frozenset([item])
            C1.add(item_set)
    return C1


def is_apriori(Ck_item, Lksub1):        # 判断新生成的项集是否满足条件
    for item in Ck_item:
        sub_Ck = Ck_item - frozenset([item])
        if sub_Ck not in Lksub1:
            return False
    return True


def aprioriGen(Lksub1, k):          # 由初始候选项集的集合Lk生成新的候选项集，K表示新项集中含有的元素个数
    Ck = set()
    len_Lksub1 = len(Lksub1)
    list_Lksub1 = list(Lksub1)
    for i in range(len_Lksub1):
        for j in range(1, len_Lksub1):
            l1 = list(list_Lksub1[i])
            l2 = list(list_Lksub1[j])
            l1.sort()
            l2.sort()
            if l1[0:k - 2] == l2[0:k - 2]:
                Ck_item = list_Lksub1[i] | list_Lksub1[j]
                # pruning
                if is_apriori(Ck_item, Lksub1):
                    Ck.add(Ck_item)
    return Ck


def scand(data_set, Ck, min_support, support_data):     # 计算Ck中的项集在数据集合d中的支持度
    Lk = set()
    item_count = {}
    for t in data_set:
        for item in Ck:
            if item.issubset(t):
                if item not in item_count:
                    item_count[item] = 1
                else:
                    item_count[item] += 1
    t_num = float(len(data_set))
    for item in item_count:
        if (item_count[item] / t_num) >= min_support:
            Lk.add(item)
            support_data[item] = item_count[item] / t_num
    return Lk                                  # 返回满足最小支持度的项集的集合，和所有项集支持度的信息的字典


def apriori(data_set, k, min_support):      # 将符合最小支持度要求的项集加入
    support_data = {}
    C1 = create_C1(data_set)
    L1 = scand(data_set, C1, min_support, support_data)
    Lksub1 = L1.copy()
    L = []
    L.append(Lksub1)
    for i in range(2, k + 1):
        Ci = aprioriGen(Lksub1, i)
        Li = scand(data_set, Ci, min_support, support_data)
        Lksub1 = Li.copy()
        L.append(Lksub1)
    return L, support_data                      # 返回满足条件的频繁项集的列表以及所有候选项集的支持度信息


# 生成强关联规则
def generateRules(L, supportdata, minConf):         # L(list) 存储频繁项集/supportdata(dict) 存储所有项集的支持度/minConf(float) 最小可信度
    bigRuleList = []
    sub_set_list = []
    for i in range(0, len(L)):
        for freq_set in L[i]:               # 计算规则的可信度
            for sub_set in sub_set_list:    # 对频繁项集中元素超过2的项集进行合并
                if sub_set.issubset(freq_set):
                    conf = supportdata[freq_set] / supportdata[freq_set - sub_set]
                    big_rule = (freq_set - sub_set, sub_set, conf)
                    if conf >= minConf and big_rule not in bigRuleList:
                        bigRuleList.append(big_rule)
            sub_set_list.append(freq_set)
    return bigRuleList
